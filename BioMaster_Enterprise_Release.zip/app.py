from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import pandas as pd

app = FastAPI(title="BioMaster AI API", description="Production API for Bioinformatics Predictions")

# 1. Loading the pre-trained models safely
protein_model = joblib.load('protein_rf_model.pkl')
encoder = joblib.load('label_encoder.pkl')
anomaly_detector = joblib.load('anomaly_detector_model.pkl')

# 2. Defining the expected input data structure
class ProteinSample(BaseModel):
    length: int
    weight: int

@app.get("/")
def home():
    return {"status": "BioMaster AI System is ONLINE and ready for requests."}

# 3. Exposing the prediction and anomaly detection endpoint
@app.post("/predict_location")
def predict_protein_location(sample: ProteinSample):
    df = pd.DataFrame([[sample.length, sample.weight]], columns=['Length', 'Mol_weight'])

    # Check for anomaly first
    is_anomaly = anomaly_detector.predict(df)[0]
    if is_anomaly == -1:
         return {"Error": " Sample rejected by Quality Control. Abnormal biological metrics detected."}

    # Make prediction if normal
    prediction = protein_model.predict(df)
    location = encoder.inverse_transform(prediction)[0]

    return {
        "Length": sample.length,
        "Weight": sample.weight,
        "Status": " Quality Passed",
        "Predicted_Location": location
    }
